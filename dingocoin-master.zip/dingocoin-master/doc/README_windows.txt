Dingocoin Core 1.18.1.1
=======================

Intro
-----
Dingocoin is a free open source peer-to-peer electronic cash system that is
completely decentralized, without the need for a central server or trusted
parties.  Users hold the crypto keys to their own money and transact directly
with each other, with the help of a P2P network to check for double-spending.


Setup
-----
Unpack the files into a directory and run dingocoin-qt.exe.

Dingocoin Core is the original Dingocoin client and it builds the backbone of the network.
However, it downloads and stores the entire history of Dingocoin transactions;
depending on the speed of your computer and network connection, the synchronization
process can take anywhere from a few hours to a day or more.

See the Dingocoin wiki at:
  https://www.reddit.com/r/dingocoin/wiki/dingocoincoreguide
for more help and information.
